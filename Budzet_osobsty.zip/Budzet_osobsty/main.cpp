#include <iostream>

#include "BudzetOsobistyManager.h"

using namespace std;

int main()
{
    char wybor;

    BudzetOsobistyMenager budzetOsobistyMenager("Uzytkownicy.txt", "Adresaci.txt");

    budzetOsobistyMenager.wypiszWszystkichUzytkownikow();

    while (true)
    {
        if (ksiazkaAdresowa.czyUzytkownikJestZalogowany() == false)
        {
            wybor = MetodyPomocnicze::wybierzOpcjeZMenuGlownego();

            switch (wybor)
            {
            case '1':
                cin.sync();
                ksiazkaAdresowa.rejestracjaUzytkownika();
                cin.sync();
                break;
            case '2':
                cin.sync();
                ksiazkaAdresowa.logowanieUzytkownika();
                cin.sync();
                break;
            case '9':
                exit(0);
                break;
            default:
                cout << endl << "Nie ma takiej opcji w menu." << endl << endl;
                system("pause");
                break;
            }
        }
    }

    return 0;
}
