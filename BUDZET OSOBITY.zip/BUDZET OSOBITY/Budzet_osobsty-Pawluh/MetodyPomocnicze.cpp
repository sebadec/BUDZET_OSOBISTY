#include "MetodyPomocnicze.h"

string MetodyPomocnicze::intToString(int number)
{
	ostringstream ss;
	ss << number;
	string str = ss.str();
	return str;
}

string MetodyPomocnicze::doubleToString(double number)
{
	ostringstream ss;
	ss << number;
	string str = ss.str();
	return str;
}

string MetodyPomocnicze::zamienPierwszaLitereNaDuzaAPozostaleNaMale(string tekst)
{
	if (!tekst.empty())
	{
		transform(tekst.begin(), tekst.end(), tekst.begin(), ::tolower);
		tekst[0] = toupper(tekst[0]);
	}
	return tekst;
}

int MetodyPomocnicze::konwersjaStringNaInt(string liczba)
{
	int liczbaInt;
	istringstream iss(liczba);
	iss >> liczbaInt;

	return liczbaInt;
}

double MetodyPomocnicze::konwersjaStringNaDouble(string liczba)
{
	double liczbaDouble;
	istringstream iss(liczba);
	iss >> liczbaDouble;

	return liczbaDouble;
}

bool MetodyPomocnicze::isNumber(string number){
    for(int i=0; i<number.length(); i++){
        if(!(number[i] >=48 && number[i] <=57) && number[i] != '.'){
            return false;
        }
    }
    return true;
}

int MetodyPomocnicze::wczytajLiczbeCalkowita()
{
	string wejscie = "";
	int liczba = 0;

	while (true)
	{
		getline(cin, wejscie);

		stringstream myStream(wejscie);
		if (myStream >> liczba)
			break;
		cout << "To nie jest liczba. Wpisz ponownie. " << endl;
	}
	return liczba;
}

char MetodyPomocnicze::wczytajZnak()
{
	string wejscie = "";
	char znak = { 0 };

	while (true)
	{
	    cin.clear();
        cin.sync();
		getline(cin, wejscie);

		if (wejscie.length() == 1)
		{
			znak = wejscie[0];
			break;
		}
		cout << "To nie jest pojedynczy znak. Wpisz ponownie." << endl;
	}
	return znak;
}

string MetodyPomocnicze::wczytajLinie()
{
	string wejscie = "";
//	cin.ignore();
	getline(cin, wejscie);
	return wejscie;
}

string MetodyPomocnicze::changeCommaToDot(string number){
    for(int i =0; i<number.length();i++){
        if(number[i] == ','){
            number[i] = '.';
            break;
        }
    }
    return number;
}

string MetodyPomocnicze::getFullDateAsStringWithDashes(int date){
    string dateAsString = MetodyPomocnicze::intToString(date);
    dateAsString.insert(4,"-");
    dateAsString.insert(7,"-");
    return dateAsString;
}

int MetodyPomocnicze::getFullDateFromString(string date){
    date.erase(4,1);
    date.erase(6,1);
    return MetodyPomocnicze::konwersjaStringNaInt(date);
}

char MetodyPomocnicze::wybierzOpcjeZMenuGlownego()
{
    char wybor;

    system("cls");
    cout << "    >>> MENU  GLOWNE <<<" << endl;
    cout << "---------------------------" << endl;
    cout << "1. Rejestracja" << endl;
    cout << "2. Logowanie" << endl;
    cout << "9. Koniec programu" << endl;
    cout << "---------------------------" << endl;
    cout << "Twoj wybor: ";
    wybor = wczytajZnak();

    return wybor;
}

char MetodyPomocnicze::wybierzOpcjeZMenuUzytkownika()
{
    char wybor;

    system("cls");
    cout << " >>> MENU UZYTKOWNIKA <<<" << endl;
    cout << "---------------------------" << endl;
    cout << "1. Dodaj przychod." << endl;
    cout << "2. Dodaj wydatek." << endl;
    cout << "3. Pokaz bilans z aktualnego miesiaca." << endl;
    cout << "4. Pokaz bilans z poprzedniego miesiaca." << endl;
    cout << "5. Pokaz bilans z wybranego okresu." << endl;
    cout << "---------------------------" << endl;
    cout << "6. Zmien haslo" << endl;
    cout << "7. Wyloguj sie" << endl;
    cout << "---------------------------" << endl;
    cout << "Twoj wybor: ";
    wybor = wczytajZnak();

    return wybor;
}
