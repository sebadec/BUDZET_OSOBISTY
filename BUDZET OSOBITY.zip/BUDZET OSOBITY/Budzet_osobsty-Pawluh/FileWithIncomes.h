#ifndef  FILEWITHINCOMES_H
#define FILEWITHINCOMES_H

#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <cstdlib>
#include <windows.h>
#include <vector>
#include "Markup.h"

#include "MetodyPomocnicze.h"
#include "TextFile.h"
#include "Income.h"

using namespace std;

class FileWithIncomes: public TextFile
{
    int lastIncomeId;
public:

    FileWithIncomes(string fileName);
    void saveIncome(Income income);
    vector <Income> loadData(int loggedUserId);

    int getLastIncomeId();
    void setLastIncomeId(int id);
/*
	string zamienDaneUzytkownikaNaLinieZDanymiOddzielonaPionowymiKreskami(Uzytkownik uzytkownik);
	Uzytkownik pobierzDaneUzytkownika(string daneJednegoUzytkownikaOddzielonePionowymiKreskami);

public:
	PlikZUzytkownikami(string nazwaPliku);
	void dopiszUzytkownikaDoPliku(Uzytkownik uzytkownik);
	vector <Uzytkownik> wczytajUzytkownikowZPliku();

	//wyzwanie
	void zapiszWszystkichUzytkownikowDoPliku(vector <Uzytkownik> &uzytkownicy);
	*/
};

#endif
