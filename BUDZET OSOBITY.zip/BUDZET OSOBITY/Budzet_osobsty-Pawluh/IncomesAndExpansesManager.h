#ifndef  INCOMEMANAGER_H
#define INCOMEMANAGER_H

#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include "Income.h"
#include "Expense.h"
#include "MetodyPomocnicze.h"
#include "FileWithIncomes.h"
#include "FileWithExpenses.h"

#include <algorithm>
#include <functional>

using namespace std;

class IncomesAndExpansesManager
{
	vector <Income> incomes;
	vector <Expense> expenses;
	FileWithIncomes incomesFile;
	FileWithExpenses expensesFile;
    int loggedUserId;

    Income setNewIncome(int id);
    int getNewIncomeId();

    Expense setNewExpense(int id);
    int getNewExpenseId();

    int getCurrentDate();
    int getCurrentDay();
    int getCurrentMonth();
    int getCurrentYear();

    int getDayFromString(string date);
    int getMonthFromString(string date);
    int getYearFromString(string date);

    //int getFullDateFromString(string date);
    //string getFullDateAsStringWithDashes(int date);

    bool isDateCorrect(string date);
    bool isDateGreaterThanCurrentDate(string date);
    bool isDayCorrect(int day, int month, int year);
    bool isMonthCorrect(int month);
    bool isYearCorrect(int year);

public:
    IncomesAndExpansesManager(int id, string fileNameWithIncomes, string fileNameWithExpenses);

    void addNewIncome(int id);
    void showIncomes();

    void addNewExpense(int id);
    void showExpenses();

    void setLoggedUserId(int id);

    vector <Income> sortIncomesFromGreater(vector <Income> tmpIncomes); //przenie�� do prywatnych
    vector <Income> sortIncomesFromLower(vector <Income> tmpIncomes); //przenie�� do prywatnych
    vector <Expense> sortExpensesFromGreater(vector <Expense> tmpExpenses); //przenie�� do prywatnych
    vector <Expense> sortExpensesFromLower(vector <Expense> tmpExpenses); //przenie�� do prywatnych

    void showBalanceForCurretnMonth();
    void shwoBalanceForPreviouslyMonth();
    void showBalanceForPeriodOfTime();
};
#endif
