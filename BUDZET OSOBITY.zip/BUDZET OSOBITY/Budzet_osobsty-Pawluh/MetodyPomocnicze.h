#ifndef  METODYPOMOCNICZE_H
#define METODYPOMOCNICZE_H

#include <iostream>
#include <sstream>
#include <algorithm>

using namespace std;

class MetodyPomocnicze
{
public:
	 static string intToString(int number);
	 static string doubleToString(double number);
	 static int konwersjaStringNaInt(string liczba);
	 static double konwersjaStringNaDouble(string liczba);

	 static bool isNumber(string number);
	 static int wczytajLiczbeCalkowita();//
	 static char wczytajZnak();//
	 static string wczytajLinie();//

     static string zamienPierwszaLitereNaDuzaAPozostaleNaMale(string tekst);//
     static string changeCommaToDot(string number);
	 static string getFullDateAsStringWithDashes(int date);
	 static int getFullDateFromString(string date);
	 static char wybierzOpcjeZMenuGlownego();
     static char wybierzOpcjeZMenuUzytkownika();

};

#endif
