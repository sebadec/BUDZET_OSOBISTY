#include "FileWithIncomes.h"

FileWithIncomes::FileWithIncomes(string fileName)
:TextFile(fileName)
{
    lastIncomeId = 0;
}

void FileWithIncomes::saveIncome(Income income)
{
    CMarkup xml;
    bool fileExists = xml.Load( loadFileName());

    if (!fileExists)
    {
        xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
        xml.AddElem("Incomes");
    }

    xml.FindElem();
    xml.IntoElem();
    xml.AddElem("Income");
    xml.IntoElem();
    xml.AddElem("IncomeId", MetodyPomocnicze::intToString(income.getEventId()));
    xml.AddElem("UserId", MetodyPomocnicze::intToString(income.getUserId()));
    xml.AddElem("Date", MetodyPomocnicze::getFullDateAsStringWithDashes(income.getDate()));
    xml.AddElem("Item", income.getItem());
    xml.AddElem("Amount", MetodyPomocnicze::doubleToString(income.getAmount()));

    xml.Save(loadFileName());
    lastIncomeId+=1;
}

vector <Income> FileWithIncomes::loadData(int loggedUserId){
    vector <Income> incomes;
    Income income;

    CMarkup xml;
    string incomeId, userId, date, item, amount;

    bool fileExists = xml.Load( loadFileName() );

    if (fileExists)
    {
        xml.FindElem();
        xml.IntoElem();
    //    xml.SetDoc("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
        while(xml.FindElem())
        {
            xml.SavePos();
            xml.IntoElem();

            xml.FindElem("IncomeId");
            incomeId = xml.GetData();
            income.setEventId(MetodyPomocnicze::konwersjaStringNaInt(incomeId));
            lastIncomeId = MetodyPomocnicze::konwersjaStringNaInt(incomeId);

            xml.FindElem("UserId");
            userId = xml.GetData();
            if(loggedUserId == MetodyPomocnicze::konwersjaStringNaInt(userId))
            {
                income.setUserId(MetodyPomocnicze::konwersjaStringNaInt(userId));
            }
            else{
                xml.RestorePos();
                continue;
            }

            xml.FindElem("Date");
            date = xml.GetData();
            income.setDate(MetodyPomocnicze::getFullDateFromString(date));

            xml.FindElem("Item");
            item = xml.GetData();
            income.setItem(item);

            xml.FindElem("Amount");
            amount = xml.GetData();
            income.setAmount(MetodyPomocnicze::konwersjaStringNaDouble(amount));

            incomes.push_back(income);
            xml.RestorePos();
        }
    }
    return incomes;
}

int FileWithIncomes::getLastIncomeId(){
    return lastIncomeId;
}

void FileWithIncomes::setLastIncomeId(int id){
    lastIncomeId=id;
}
