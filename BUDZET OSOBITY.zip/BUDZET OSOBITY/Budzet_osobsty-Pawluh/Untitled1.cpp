#include <iostream>

#include "UserManager.h"
#include "IncomesAndExpansesManager.h"
#include "Finances.h"

using namespace std;

int main()
{
 //   UserManager manager;

//	manager.userRegistration();
//	manager.userRegistration();

//	manager.showRegistredUsers();
//	manager.userLoging();
//	cout << endl << manager.getLoggedUserId() << endl;
 //   manager.loadData();


//    cos.showIncomes();
//    cos.addNewIncome(1);
 //   cos.addNewIncome(2);
 //   cos.addNewExpense(1);
 //   cos.addNewExpense(1);
 //   cos.showExpenses();

 //   cos.showIncomes();


//    finances.userRegistration();
 //   finances.userRegistration();
    //finances.userLogin();
//    finances.addNewIncome();
 //   finances.addNewExpense();

//    finances.changePassword();
//    finances.logout();
 //   finances.addNewIncome();


 //   IncomesAndExpansesManager cos(1);
//    cos.addNewIncome(1);
//    cos.addNewIncome(1);
 //   cos.addNewIncome(1);
//    cos.addNewExpense(1);
//    cos.addNewExpense(1);
//    cos.addNewExpense(1);
//    cos.showBalanceForCurretnMonth();
//    cos.shwoBalanceForPreviouslyMonth();
//    cos.showBalanceForPeriodOfTime();

//    finances.showBalanceForCurretnMonth();
 //   finances.shwoBalanceForPreviouslyMonth();
    //finances.showBalanceForPeriodOfTime();

    Finances finances("users.xml", "incomes.xml", "expenses.xml");

    char wybor;

    while (true)
    {
        if (finances.isUserLogged() == false)
        {
            wybor = MetodyPomocnicze::wybierzOpcjeZMenuGlownego();

            switch (wybor)
            {
            case '1':
                finances.userRegistration();
                break;
            case '2':
                finances.userLogin();
                break;
            case '9':
                exit(0);
                break;
            default:
                cout << endl << "Nie ma takiej opcji w menu." << endl << endl;
                system("pause");
                break;
            }
        }
        else
        {
            wybor = MetodyPomocnicze::wybierzOpcjeZMenuUzytkownika();

            switch (wybor)
            {
            case '1':
                finances.addNewIncome();
                break;
            case '2':
                finances.addNewExpense();
                break;
            case '3':
                finances.showBalanceForCurretnMonth();
                break;
            case '4':
                finances.shwoBalanceForPreviouslyMonth();
                break;
            case '5':
                finances.showBalanceForPeriodOfTime();
                break;
            case '6':
                finances.changePassword();
                break;
            case '7':
                finances.logout();
                break;
            default:
                cout << endl << "Nie ma takiej opcji w menu." << endl << endl;
                system("pause");
                break;
            }
        }
    }
    return 0;
}
