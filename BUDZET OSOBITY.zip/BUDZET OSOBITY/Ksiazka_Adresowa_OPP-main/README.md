# Ksiazka_Adresowa_OPP
Książka Adresowo napisana obiektowo przez Sebastiana Deca (z dużą pomocą Artura i jego ekipy [dzięki Dominik za prowadenie])
