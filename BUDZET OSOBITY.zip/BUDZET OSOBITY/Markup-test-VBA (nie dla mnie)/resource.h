//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Markup.rc
//
#define ID_APP_VERSION                  1
#define IDD_MARKUP_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP_TESTDLG              129
#define IDC_EDIT_FILE                   1000
#define IDC_BUTTON_BROWSE               1001
#define IDC_BUTTON_PARSE                1002
#define IDC_ST_PARSE_RESULTS            1003
#define IDC_ST_TEST_RESULTS             1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
